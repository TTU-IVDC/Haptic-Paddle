Copy Folder "PID_v1" into the automatically created library folder (Documents -> Arduino ->libraries-> PID_v1)

Upload one of the PIDControllers to the Haptic Paddle. Use the one labeled for processing if you will be using the processing interface.