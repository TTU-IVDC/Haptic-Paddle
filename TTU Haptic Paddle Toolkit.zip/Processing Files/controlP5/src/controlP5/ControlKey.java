package controlP5;

public interface ControlKey {

	public void keyEvent();
}
